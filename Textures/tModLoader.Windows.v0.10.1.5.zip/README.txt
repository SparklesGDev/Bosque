If you are upgrading from 0.9.2.3 for 1.3.5, please use steam to "verify integrity of game files" before attempting to install.

To install tModLoader, simply run the tModLoaderInstaller.jar file. Java 1.7 or higher is required for the installer to run. The installer will make a window pop up, informing you of either success or failure.

If the installer for some reason does not work, or if you do not want to install/upgrade Java, you may also do a manual install. Go to your Terraria's Steam folder; for most people, this will be "C:\Program Files (x86)\Steam\SteamApps\common\Terraria". Then, copy all these files into that folder. You may wish to back-up your vanilla Terraria.exe first.